$(document).ready(function(){
	//http://jqueryui.com/demos/tabs/
    $("#search_tabs").tabs();

});