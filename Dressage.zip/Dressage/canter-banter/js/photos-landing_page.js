/*
 * Viewport - jQuery selectors for finding elements in viewport
 *
 * Copyright (c) 2008-2009 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *  http://www.appelsiini.net/projects/viewport
 *
 */
(function($) {
    
    $.belowthefold = function(element, settings) {
        var fold = $(window).height() + $(window).scrollTop();
        return fold <= $(element).offset().top - settings.threshold;
    };

    $.abovethetop = function(element, settings) {
        var top = $(window).scrollTop();
        return top >= $(element).offset().top + $(element).height() - settings.threshold;
    };
    
    $.rightofscreen = function(element, settings) {
        var fold = $(window).width() + $(window).scrollLeft();
        return fold <= $(element).offset().left - settings.threshold;
    };
    
    $.leftofscreen = function(element, settings) {
        var left = $(window).scrollLeft();
        return left >= $(element).offset().left + $(element).width() - settings.threshold;
    };
    
    $.inviewport = function(element, settings) {
        return !$.rightofscreen(element, settings) && !$.leftofscreen(element, settings) && !$.belowthefold(element, settings) && !$.abovethetop(element, settings);
    };
    
    $.extend($.expr[':'], {
        "below-the-fold": function(a, i, m) {
            return $.belowthefold(a, {threshold : 0});
        },
        "above-the-top": function(a, i, m) {
            return $.abovethetop(a, {threshold : 0});
        },
        "left-of-screen": function(a, i, m) {
            return $.leftofscreen(a, {threshold : 0});
        },
        "right-of-screen": function(a, i, m) {
            return $.rightofscreen(a, {threshold : 0});
        },
        "in-viewport": function(a, i, m) {
            return $.inviewport(a, {threshold : 0});
        }
    });

    
})(jQuery);

$(function () {
    var api_key = '0173b034bfe3753f522767c8359700e5';
    var user_id = '79641819@N08';

    /*
    use:
    Square,Thumbnail,Small,Medium or Original for the large image size you want to load!
    */
    var large_image_size = 'Medium';
    /*
    the current Set id / the current Photo id
    */
    var photo_set_id, photo_id;
    var current = -1;
    var continueNavigation = false;
    /*
    flickr API Call to get List of Sets
    */
    var sets_service = 'http://api.flickr.com/services/rest/?&method=flickr.photosets.getList' + '&api_key=' + api_key;
    var sets_url = sets_service + '&user_id=' + user_id + '&format=json&jsoncallback=?';
    /*
    flickr API Call to get List of Photos from a Set
    */
    var photos_service = 'http://api.flickr.com/services/rest/?&method=flickr.photosets.getPhotos' + '&api_key=' + api_key + '&privacy_filter=1';
    /*
    flickr API Call to get List of Sizes of a Photo
    */
    var large_photo_service = 'http://api.flickr.com/services/rest/?&method=flickr.photos.getSizes' + '&api_key=' + api_key;
    /* 
    elements caching... 
    */
    var $setsContainer = $('#sets').find('ul');
    var $photosContainer = $('#images').find('ul');
    var $photopreview = $('#flickr_photopreview');
    var $flickrOverlay = $('#flickr_overlay');
    var $loadingStatus = $('#flickr_toggle').find('.loading_small');

    var ul_width, spacefit, fit;


    /*
    Loads the User Photo Sets
    */
    LoadSets();
    function LoadSets() {
        $loadingStatus.css('visibility', 'visible');

        $.getJSON(sets_url, function (data) {
            if (data.stat != 'fail') {
                var sets_count = data.photosets.photoset.length;
                /*
                adapt ul width based on number of results
                */
                //ul_width = sets_count * 85 + 85;
                //$setsContainer.css('width',ul_width + 'px');
                /*custom code Melissa Snell to get list. There is an umbraco macro on the page just prior to the reference to this 
                    script file that creates a variable called setIdsPublished that holds a comma-separated string of all of the published set ids that we have	
                    */
                var arrIdsToProcess = setIdsPublished.split(",");
                /*extend array funcitonality by adding has method*/
                Array.prototype.has = function (value) {
                    var loopCnt = this.length;
                    for (var k = 0; k < loopCnt; k++) {
                        if (this[k] == value) {
                            return true;
                        }
                    }
                    return false;
                };

                for (var i = 0; i < sets_count; ++i) {
                    var photoset = data.photosets.photoset[i];
                    var primary = photoset.primary;
                    var secret = photoset.secret;
                    var server = photoset.server;
                    var farm = photoset.farm;
                    /*
                    source for the small thumbnail
                    */
                    var photoUrl = 'http://farm' + farm + '.static.flickr.com/' + server + '/' + primary + '_' + secret + '_m.jpg';
                    var $elem = $('<li />');

                    //  var tsetname = photoset.title._content
                    var tsetname = photoset.title._content.replace(/( +- *)|(- +)|( +)/g, '-').toLowerCase(); //we need to account for spaces and existing hypens on URL will not match the one in 
                    var $link = $('<a class="toLoad" href="/canter-banter/photos/' + tsetname + '" />');

                    /*
                    save the info of the set in the li element,
                    we will use it later
                    Ammendment by Melissa Snell for Canter Banter - BUT only do this if it is one of the published sets in the CMS. */


                    /* only add if it is in our list*/
                    if (arrIdsToProcess.has(photoset.id)) {
                        $link.data({
                            'primary': primary,
                            'secret': secret,
                            'server': server,
                            'farm': farm,
                            'photoUrl': photoUrl,
                            'setName': photoset.title._content,
                            'id': photoset.id
                        });


                        $setsContainer.append($elem.append($link));
                    }
                }
                /*
                now we load the images 
                (the ones in the viewport)
                */

                LoadSetsImages();
                $('#sets li:nth-child(3n)').addClass('last');
            }
        });
    }

    /*
    loads the images of the sets that are in the viewport
    */
    function LoadSetsImages() {
        var toLoad = $('.toLoad:in-viewport').size();
        if (toLoad > 0)
            $loadingStatus.css('visibility', 'visible');
        var images_loaded = 0;
        $('.toLoad:in-viewport').each(function (i) {
            var $space = $setsContainer.find('.toLoad:first');
            var $img = $('<img style="display:none;" />').load(function () {
                ++images_loaded;
                if (images_loaded == toLoad) {
                    $loadingStatus.css('visibility', 'hidden');
                    $setsContainer.find('img').fadeIn();
                }
            }).error(function () {
                //TODO
                ++images_loaded;
                if (images_loaded == toLoad) {
                    $loadingStatus.css('visibility', 'hidden');
                    $setsContainer.find('img').fadeIn();
                }
            }).attr('src', $space.data('photoUrl')).attr('alt', $space.data('id'));
            var $set_name = $('<h2 />', { 'html': $space.data('setName') });
            $space.after($set_name).append($img).removeClass('toLoad');
        });
    }


});