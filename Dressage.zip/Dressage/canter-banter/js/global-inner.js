$(document).ready(function(){
	
	//adjust the content width depending on what is enabled
	$leftcol = $(".left-col").width();
	$rightcol = $(".right-col").width();
	$skyscraper = 120;
	$widgets = 220;
	$sidemenu = 240;
	$mpu = 300;
	$w0 = 0;
	
	//alert($leftcol = $(".left-col").width());
	
	if($leftcol == $sidemenu) {
		$("body").addClass('submenu');
	}	
	if($rightcol == $mpu) {
		$("body").addClass('mpu-enabled');
	}	
	if($rightcol == $skyscraper) {
		$("body").addClass('skyscraper-enabled');
	};
	if($rightcol == $widgets) {
		$("body").addClass('right-col-widgets-enabled');
	};
	if($rightcol == $w0) {
		$("body").addClass('right-col-disabled');
	};		
	if($leftcol == $w0) {
		$("body").addClass('left-col-disabled');
	};	
	if($leftcol == $w0 && $rightcol == $w0) {
		$("body").addClass('full_width');
	};	
	

	$h1 = $(".box.my_details").height();
	$h2 = $(".box.avatar").height();
	if($h2 >= $h1) {
		$(".box.my_details").height($h2);
	};		
	
	
	
	
	$h3 = $(".your_details").height();
	$h4 = $(".your_address").height();
	if($h4 >= $h3) {
		$(".your_details").height($h4);
	};
	
	
	
	
	
	//ambassadors / classifieds / photos & videos
	$('.boxes li:nth-child(3n),.list-classified-categories li:nth-child(3n),#sets li:nth-child(3n)').addClass('last');
	
	$(".boxes li,.list-classified-categories li,#sets li").live("click",function() {
		self.location = $(this).find('a').attr("href");
	});
	
	
	
	
	// registration
	$("#datepicker").datepicker({
		changeMonth: true,
		changeYear: true,
		yearRange: '1900:+0'
	});
	//

	
	//product page gallery
	//$('#thumbs').delegate('img','click', function(){
//		$('#largeImage').attr('src',$(this).attr('src').replace('thumb','large'));
		//$('#panel a').attr('href',$(this).attr('src').replace('thumb','fullsize'));
		//$('#description').html($(this).attr('alt'));
//	});
	
	


	
});






/*
 * Style File - jQuery plugin for styling file input elements
 *  
 * Copyright (c) 2007-2009 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Based on work by Shaun Inman
 *   http://www.shauninman.com/archive/2007/09/10/styling_file_inputs_with_css_and_the_dom
 *
 */

(function($) {
    
    $.fn.filestyle = function(options) {
                
        /* TODO: This should not override CSS. */
        var settings = {
            width : 250
        };
                
        if(options) {
            $.extend(settings, options);
        };
                        
        return this.each(function() {
            
            var self = this;
            var wrapper = $("<div>")
                            .css({
                                "width": settings.imagewidth + "px",
                                "height": settings.imageheight + "px",
                                "background": "url(" + settings.image + ") 0 0 no-repeat",
                                "background-position": "right",
                                "display": "inline",
                                "position": "absolute",
                                "overflow": "hidden",
                                "top": "4px",
                                "right": "22px",
                                "cursor": "pointer"
                            });
                            
            var filename = $('<input class="file">')
                             .addClass($(self).attr("class"))
                             .css({
                                 "display": "inline",
                                 "width": settings.width + "px"
                             });

            $(self).before(filename);
            $(self).wrap(wrapper);

            $(self).css({
                        "position": "relative",
                        "height": settings.imageheight + "px",
                        "width": settings.width + "px",
                        "display": "inline",
                        "cursor": "pointer",
                        "opacity": "0.0"
                    });

            if ($.browser.mozilla) {
                if (/Win/.test(navigator.platform)) {
                    $(self).css("margin-left", "-142px");                    
                } else {
                    $(self).css("margin-left", "-168px");                    
                };
            } else {
                $(self).css("margin-left", settings.imagewidth - settings.width + "px");                
            };

            $(self).bind("change", function() {
                //filename.val($(self).val());
            	var s = $(self).val().replace(/(c:\\)*fakepath/i, '');
                filename.val(s);            	
            });
      
        });
        

    };
    
})(jQuery);


$(document).ready(function(){
	$("input.browse").filestyle({ 
        image: "/img/browse.png",
        imageheight : 35,
        imagewidth : 61,
        width : 290
    });


});

jQuery(window).load(function() {
	//var teest = $('.twitter-share-button twitter-count-none').contents().find('#b').html();
	//alert($(teest).size());
	
//	$('.twitter-share-button twitter-count-none').contents().find('#b').on("click", "div",  function () {
	    //var a = this.id;
	    //alert (a);
	    //return false;
	//});
	
	
});