$(document).ready(function(){
	$("#signed_in-menu").removeClass("nojs");
	$("#signed_in-menu-trigger").removeClass("nojs");
	$("#signed_in-menu-trigger,#bar-top nav li.first > a").click(function(){
		var dd = $("#signed_in-menu");
		if(dd.css("top")=="-10000px"){dd.addClass("jsopen");
		$("#signed_in-menu-trigger").addClass("open");
	}else{
		dd.removeClass("jsopen");
		$("#signed_in-menu-trigger").removeClass("open");
	}
	return false;
	});
	$('#signed_in-menu').click(function(e){e.stopPropagation();});
	$(document).click(function(){
		$("#signed_in-menu").removeClass("jsopen");
		$("#signed_in-menu-trigger").removeClass("open");		
	});	
});