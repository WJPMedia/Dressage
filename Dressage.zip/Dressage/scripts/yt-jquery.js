//=========== javascript to capture the image comments, move them to the hidden image comments form, then submit them.========

function formValue() {
    // get values from form on image comments pop up
    var listObj = document.forms["innerForm"].name.value;
    var listObj1 = document.forms["innerForm"].email.value;
    var listObj2 = document.forms["innerForm"].comment.value;
    var listObj3 = document.forms["innerForm"].ImageID.value;


    //get element IDs from main image comment form
      var nextObj = document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$Contact$txtName
    var nextObj1 = document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$Contact$txtEmail
    var nextObj2 = document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$Contact$txtMessage;
    var nextObj3 = document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$Contact$txtWebsite
    //pass values to main image comment form
    nextObj.value = (listObj);
    nextObj1.value = (listObj1);
    nextObj2.value = (listObj2);
    nextObj3.value = (listObj3);
   

    // close pop up box
    jQuery.fancybox.close();

    //fire button event on main image comment form
   // document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$ImageContact_10$btnSubmit.click()
    document.forms["ctl00"].ctl00$ctl00$ctl00$ctl00$ContentPlaceHolderDefault$ContentPlaceHolderDefault$LeftCol$Contact$btnSubmit.click()
    return false;


}

//========sliding out widget ===============
$(function () {
    $("#webwidget_menu_glide3").webwidget_menu_glide(
        { menu_width: "110",
            menu_height: "13",
            menu_text_size: "13",
            menu_text_color: "#808080",
            menu_sprite_color: "",
            menu_background_color: "",
            menu_margin: "0",
            sprite_speed: "normal",
            container: "webwidget_menu_glide3"
        });
});


//instagram panel
//HELP FROM HERE...
//https://forrst.com/posts/Using_the_Instagram_API-ti5

// small = + data.data[i].images.thumbnail.url +
// resolution: low_resolution, thumbnail, standard_resolution

$(function () {
    $.ajax({
        type: "GET",
        dataType: "jsonp",
        cache: false,
        //url: "https://api.instagram.com/v1/users/18360510/media/recent/?access_token=18360510.f59def8.d8d77acfa353492e8842597295028fd3",
        url: "https://api.instagram.com/v1/users/9453373/media/recent/?access_token=9453373.dce2065.83a486407b974c6eaf89ed6466495a70",
        success: function (data) {
            for (var i = 0; i < 6; i++) {
                $(".instagram").append("<div class='instagram-placeholder'><a target='_blank' href='" + data.data[i].link + "'><img class='instagram-image' border='0' src='" + data.data[i].images.thumbnail.url + "' /></a></div>");
            }

        }
    });
});

/**
*  Plugin which renders the YouTube channel videos list to the page
*/

var __mainDiv;
var __preLoaderHTML;
var __opts;

function __jQueryYouTubeChannelReceiveData(data) {

    var cnt = 0;

    $.each(data.feed.entry, function (i, e) {
        if (cnt < __opts.numberToDisplay) {
            var parts = e.id.$t.split('/');
            var videoId = parts[parts.length - 1];
            var out = '<div class="video"><a rel="' +
                  videoId + '" class="ytLink"><img src="http://i.ytimg.com/vi/' +
                  videoId + '/2.jpg"/></a><br /><span rel="' +
                  videoId + '" class="ytLink">' + e.title.$t + '</span><p>';
            if (!__opts.hideAuthor) {
               // out = out + 'Author: ' + e.author[0].name.$t + '';
            }
            out = out + '</p></div>';
            __mainDiv.append(out);
            cnt = cnt + 1;
        }
    });

    // Open in new tab?
    if (__opts.linksInNewWindow) {
        $(__mainDiv).find("li > a").attr("target", "_blank");
    }

    // Remove the preloader and show the content
    $(__preLoaderHTML).remove();
    __mainDiv.show();

    /* !CREATE VIDEO PLAYER */
    $("a.ytLink").each(function () {
        $(this).css("cursor", "pointer");
        $(this).click(function () {
            ytVid = $(this).attr("rel");
            //alert("yo "+ytVid);
            $("#youtubevideos").prepend("<div id='ytPlayer' class='ui-draggabl' style='left: 36px; top: 5px;'><a href='#' id='ytplrCls' style='color:white;' onClick=$('#ytPlayer').remove();>[x] CLOSE</a><div id='ytPlayerInr'><object width='640' height='385'><param name='movie' value='http://www.youtube.com/v/" + ytVid + "&hl=en_US&fs=1&'></param><param name='allowFullScreen' value='true'></param><param name='allowscriptaccess' value='always'></param><embed src='http://www.youtube.com/v/" + ytVid + "&hl=en_US&fs=1&' type='application/x-shockwave-flash' allowscriptaccess='always' allowfullscreen='true' width='640' height='385'></embed></object></div></div>");
            $("#ytPlayer").draggable({ cancel: "#ytPlayerInr", containment: '#innerBody', scroll: false });
            $("#ytplrCls").click(function () {
                 $("#ytPlayer").close();
                $("#ytPlayer").remove();
               
            });

        });
    });

}


(function ($) {
    $.fn.youTubeChannel = function (options) {
        var videoDiv = $(this);

        $.fn.youTubeChannel.defaults = {
            //userName: null,
            // channel: "uploads", //options are favorites or uploads
            loadingText: "Loading..."
            // numberToDisplay: 3,
            // linksInNewWindow: true,
            //hideAuthor: true
        }

        __opts = $.extend({}, $.fn.youTubeChannel.defaults, options);

        return this.each(function () {
            if (__opts.userName != null) {
                videoDiv.append("<div id=\"channel_div\"></div>");
                __mainDiv = $("#channel_div");
                __mainDiv.hide();

                __preLoaderHTML = $("<p class=\"loader\">" +
                    __opts.loadingText + "</p>");
                videoDiv.append(__preLoaderHTML);

                // TODO: Error handling!
                $.ajax({
                    url: "http://gdata.youtube.com/feeds/base/users/" + __opts.userName + "/" + __opts.channel + "?alt=json",
                    cache: true,
                    dataType: 'jsonp',
                    success: __jQueryYouTubeChannelReceiveData
                });
            }
        });
    };
})(jQuery);
     

