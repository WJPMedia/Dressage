Hrd.define('Harrods.Scene', Hrd.extend({
    _fopen: false, // footer open
    _nopen: false, // nav open
    _isover: false, // nav open
    init: function (config) {
        Hrd.apply(this._config, config);
       
        if (this._isIpad) {
            $('#nav a').on('click.harrods.scene', $.proxy(this.onNavIpad, this));
        } else {
            $('#nav, #subnav').on({
                mouseover: $.proxy(this.onOver, this),
                mouseleave: $.proxy(this.onNavOut, this)
            });

            $('.categories').on('mouseover', $.proxy(this.onCatOver, this));

            $('#nav a').on({
                mouseover: $.proxy(this.onNav, this),
                'click.harrods.scene': $.proxy(this.onClick, this)
            });
        }


       
    onClick: function (evt) {
        $('#nav a').removeClass('active');
        $(evt.target).addClass('active');
        var p = ($(evt.target).position().left - 140) + $(evt.target).width() / 2 - 11 + 20;
        $('#nav').animate({ 'background-position-x': p + 'px' }, 1000, 'easeOutExpo');
        return false;
    },
   
    onOver: function (evt) {
        var id = $(evt.target).closest('.categories').attr('id');
        if (id != undefined) {
            id = id.replace('sub_', '');
            $('#' + id).addClass('overed');
        }

        this.isOver = true;
    },
    onNav: function (evt) {
        $("#nav a").removeClass('overed');
        var id = $(evt.target).attr('id');
        if (!this._nopen) {
            $('#subnav').show();
            $('.categories').hide();
            $("#sub_" + id).show();
            $('#subnav').hide();
            //            $('#subnav').height($("#sub_" + id).height());
            $('#subnav').stop(true, true).slideDown(1000, 'easeOutExpo');
            this._nopen = true;
        } else {
            this.scrollSubNav($("#sub_" + id), true);
        }
    },
    scrollSubNav: function (elt, animate) {

        if (!animate) {
            $('#subnav').height(elt.height());
            elt.show();
        } else {
            $('#subnav').stop(true, true).animate({ 'height': elt.height() }, 600, 'easeOutExpo');
            if ($('.categories:visible') != elt) {
                $('.categories:visible').fadeOut(100, function () {
                    elt.fadeIn(300);
                });
            }
        }
    },
    onNavOut: function () {
        this.isOver = false;
        if (this._nopen) {
            var _self = this;
            setTimeout(function () {
                if (!_self.isOver) {
                    $("#nav a").removeClass('overed');
                    _self._nopen = false;
                    $('#subnav').stop(true, true).slideUp(1000, 'easeOutExpo');
                }
            }, 500);
        }
    },
    onNavIpad: function (evt) {

        var id = $(evt.target).attr('id');
        $(".categories").hide();
        $("#sub_" + id).show();
        if (!this._nopen) {
            $('#subnav').stop(true, true).slideDown();
            this._nopen = true;
            $('body').on('touchstart.harrods.scene', $.proxy(this.onNavOutIpad, this));
        }

        $('#nav a').removeClass('active');
        $(evt.target).addClass('active');
        $("#currentBlock h3 span, #az-block h3 span").text($(evt.target).text())
        evt.stopPropagation();
        evt.preventDefault();
    },
    onNavOutIpad: function (evt) {
        if (this._nopen && !$(evt.target).is('a')) {
            this._nopen = false;
            $('#subnav').stop(true, true).slideUp();
            $('body').off('touchstart.harrods.scene');
        }
        if (this._fopen && !$(evt.target).is('a')) {
            this._fopen = false;
            $('.legal').hide();
            $('footer').stop().animate({ height: '40px' });
            $('body').off('touchstart.harrods.scene');
        }
    },

   
}));
