﻿/* UWEBSHOP CLASS */

if (typeof uWebshop === 'undefined') { var uWebshop = {}; }

(function () {

    /* UWEBSHOP PUBLIC METHODS */

    uWebshop.GetOrderInfo = function (success, error) {
        var params = null, formData = null;
        return uWebshopService.callBase('GetOrderInfo', params, formData, success, error, false);
    };
    
    uWebshop.GetOrderInfoByUniqueId = function (orderGuid, success, error) {
        var params = [orderGuid], formData = null;
        return uWebshopService.callBase('GetOrderInfoByUniqueId', params, formData, success, error, true);
    };
    
    uWebshop.ConfirmOrder = function (confirmNodeId, success, error) {
        var params = [confirmNodeId], formData = null;
        return uWebshopService.callBase('ConfirmOrder', params, formData, success, error, true);
    };

    uWebshop.AddOrUpdateOrderLine = function (productId, action, quantity, variants, text, imageId, success, error) {
        var params = [productId, action, quantity, variants, text, imageId], formData = null;
        return uWebshopService.callBase('AddOrUpdateOrderLine', params, formData, success, error, true);
    };

    uWebshop.AddPaymentProvider = function (paymentProviderId, paymentMethodId, success, error) {
        var params = [paymentProviderId, paymentMethodId], formData = null;
        return uWebshopService.callBase('AddPaymentProvider', params, formData, success, error, true);
    };

    uWebshop.AddShippingProvider = function (shippingProviderId, shippingMethodId, success, error) {
        var params = [shippingProviderId, shippingMethodId], formData = null;
        return uWebshopService.callBase('AddShippingProvider', params, formData, success, error, true);
    };

    uWebshop.AddCoupon = function (couponCode, success, error) {
        var params = [couponCode], formData = null;
        return uWebshopService.callBase('AddCoupon', params, formData, success, error, true);
    };

    uWebshop.AddCustomerFields = function (customerFields, success, error) {
        var params = [customerFields], formData = null;
        return uWebshopService.callBase('AddCustomerFields', params, formData, success, error, false);
    };

    uWebshop.AddShippingFields = function (shippingFields, success, error) {
        var params = [shippingFields], formData = null;
        return uWebshopService.callBase('AddShippingFields', params, formData, success, error, false);
    };

    uWebshop.AddExtraFields = function (extraFields, success, error) {
        var params = [extraFields], formData = null;
        return uWebshopService.callBase('AddExtraFields', params, formData, success, error, false);
    };


    uWebshop.GetPaymentProviders = function (success, error) {
        var params = null, formData = null;
        return uWebshopService.callBase('GetPaymentProviders', params, formData, success, error, false);
    };

    uWebshop.GetShippingProviders = function (success, error) {
        var params = null, formData = null;
        return uWebshopService.callBase('GetShippingProviders', params, formData, success, error, false);
    };


    /* UWEBSHOP PRIVATE SERVICE OBJECT */

    var uWebshopService = function () {

        uWebshopService.callBase = function (methodName, args, data, success, error, useArgs) {
            $.ajax({
                type: "GET",
                url: uWebshopService.createUrl(methodName, args, useArgs),
                data: args,
                async: true,
                processData: false,
                success: function (data, status, xmlHttpRequest) {
                    if (success) {
                        success(data);
                    }
                },
                error: function (xmlHttpRequest, status, errorThrown) {
                    if (error) {
                        error(xmlHttpRequest, status, errorThrown);
                    }
                },
                cache: false,
                contentType: "application/json",
                dataType: "json"
            });
        };

        uWebshopService.createUrl = function (method, args, useArgs) {
            var baseUrl = '/Base/uWebshop/' + method;
            var argList = "";
            if (args) {
                for (var i = 0; i < args.length; i++) {
                    argList += '/' + args[i];
                }
            }

            if (useArgs) {
                baseUrl += argList;
            }

            return baseUrl + ".aspx";
        };
    };
    var uwbsService = new uWebshopService();

})();