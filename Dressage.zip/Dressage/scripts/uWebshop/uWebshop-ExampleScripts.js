﻿// UWEBSHOP EXAMPLE SCRIPTS

$(document).ready(function () {

    $.fn.GetOrderInfo = function () {
        uWebshop.GetOrderInfo(
      function (data) {
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };
    
    $.fn.GetOrderInfoByUniqueId = function (orderGuid) {
        uWebshop.GetOrderInfoByUniqueId(orderGuid,
      function (data) {
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.ConfirmOrder = function (confirmNodeId) {
        uWebshop.ConfirmOrder(confirmNodeId,
      function (data) {
          alert('success');
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddOrUpdateOrderLine = function (productId, action, quantity, variants, text, imageId) {
        uWebshop.AddOrUpdateOrderLine(productId, action, quantity, variants, text, imageId,
      function (data) {
          alert('success');
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddPaymentProvider = function (paymentProviderId, paymentMethodId) {
        uWebshop.AddPaymentProvider(paymentProviderId, paymentMethodId,
      function (data) {
          alert('success');
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddShippingProvider = function (shippingProviderId, shippingMethodId) {
        uWebshop.AddShippingProvider(shippingProviderId, shippingMethodId,
      function (data) {
          alert('success');
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddCoupon = function (couponCode) {
        uWebshop.AddCoupon(couponCode,
      function (data) {
          alert('success');
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddCustomerFields = function (customerFields) {
        uWebshop.AddCustomerFields(customerFields,
      function (data) {
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddShippingFields = function (shippingFields) {
        uWebshop.AddShippingFields(shippingFields,
      function (data) {
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.AddExtraFields = function (extraFields) {
        uWebshop.AddExtraFields(extraFields,
      function (data) {
          console.log(data);
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $.fn.GetPaymentProviders = function () {
        uWebshop.GetPaymentProviders(
      function (data) {
          console.log(data);
          var output = JSON.stringify(data);

          alert(output)
      },
      function (request, status, error) {
          alert('Error: ' + request.responseText);
      });
    };

    $.fn.GetShippingProviders = function () {
        uWebshop.GetShippingProviders(
      function (data) {
          console.log(data);
          var output = JSON.stringify(data);

          alert(output)
      },
      function (request, status, error) {
          alert(request.responseText);
      });
    };

    $('#customerSubmit').click(function (event) {
        // stop href from firing
        event.preventDefault();
        // get all the fields where the id starts with "customer"
        var $customerInputs = $('input[type=text][id^="customer"]');
        // build an object array out of them
        var obj = {};
        $.each($customerInputs, function () {
            obj[this.id] = $(this).val();
        });

        // create JSON from the object
        var output = JSON.stringify(obj);

        // add them to the order
        $.fn.AddCustomerFields(output);
    });

    $('#paymentsubmit').click(function (event) {
        // stop href from firing
        event.preventDefault();
        // select the chosen provider
        var selectedProvider = $("#paymentProvider option:selected").val();
        // split the value to have Provider & the method values separated
        var selectedProviderArray = selectedProvider.split('-');
        // add to order
        $.fn.AddPaymentProvider(selectedProviderArray[0], selectedProviderArray[1]);
    });

    $('#shippingsubmit').click(function (event) {
        // stop href from firing
        event.preventDefault();
        // select the chosen provider
        var selectedProvider = $("#shippingProvider option:selected").val();
        // split the value to have Provider & the method values separated
        var selectedProviderArray = selectedProvider.split('-');
        // add to order
        $.fn.AddShippingProvider(selectedProviderArray[0], selectedProviderArray[1]);
    });

    $('#confirmOrder').click(function (event) {
        // stop href from firing
        event.preventDefault();
        // confirm order
        $.fn.ConfirmOrder(0);
    });
});