$('.cycle-carousel').cycle({
	slides: '> div',
	fx: 'carousel',
	carouselVertical: true,
	carouselVisible: 3,
	allowWrap: false,
	timeout: 0
});


